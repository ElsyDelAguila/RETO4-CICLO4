package MadreSelvaCosmetics4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cosmetics4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
