package MadreSelvaCosmetics4.repository.crud;


import MadreSelvaCosmetics4.model.Cosmetics4;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 *
 * @author Elsy Del Águila
 */
public interface Cosmetics4CrudRepository extends MongoRepository<Cosmetics4, String> {
    
}
